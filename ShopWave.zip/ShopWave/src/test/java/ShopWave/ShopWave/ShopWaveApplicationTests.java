package ShopWave.ShopWave;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopWaveApplicationTests {

	@Test
	void contextLoads() {
	}

}
